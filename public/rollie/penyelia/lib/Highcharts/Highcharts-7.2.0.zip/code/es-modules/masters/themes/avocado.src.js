/**
 * @license Highcharts JS v7.2.0 (2019-09-03)
 * @module highcharts/themes/avocado
 * @requires highcharts
 *
 * (c) 2009-2019 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/avocado.js';
